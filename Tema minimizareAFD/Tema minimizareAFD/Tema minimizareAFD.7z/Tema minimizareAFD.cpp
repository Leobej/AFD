#include<iostream>
#include"AFD.h"
int main()
{
	AFD afd;
	afd.citire();
	afd.afisare();
	afd.minimizare();
	return 0;
}